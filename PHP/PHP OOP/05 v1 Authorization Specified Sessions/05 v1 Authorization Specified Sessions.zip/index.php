<?php 

echo '<a href="secret.php">Secret =>only open after login</a><br/>'; 
echo '<a href="login.php">Login</a><br/>';
echo '<a href="logout.php">Logout</a>';